Create your own gifs and images using InkScape!
